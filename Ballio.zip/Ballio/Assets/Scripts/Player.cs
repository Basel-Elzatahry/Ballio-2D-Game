using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;



public class Player : MonoBehaviour
{
    // movement variables
    public float mvmForce;
    public float jmpForce;

    private Rigidbody2D rb2d;

    // graphics variables
    public Sprite shrinking;
    public Sprite normal;
    public SpriteRenderer mySpriteRenderer;

    public int maxHealth = 5;
    public int currentHealth;
    public HealthBar healthBar;

    public Score scoreBar;
    public int score = 0;

    //misc
    private float halfLife = 5;
    private AudioSource myAudioSource;

    public AudioClip eat;
    public AudioClip hit;



    // Start is called before the first frame update
    void Start()
    {
        mySpriteRenderer = GetComponent<SpriteRenderer>();
        rb2d = GetComponent<Rigidbody2D>();
        myAudioSource = GetComponent<AudioSource>();
        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
    }

    // Update is called once per frame
    void Update()
    {
        //movement
        if (Input.GetKeyDown(KeyCode.R)){
            Reset();
        }
        if (Input.GetKey(KeyCode.D))
            {
                rb2d.AddForce(new Vector2(mvmForce, 0) * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.A))
            {
                rb2d.AddForce(new Vector2(-mvmForce, 0) * Time.deltaTime);
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, 0.1f);
            if (hit.collider != null)
            {
                Jump();
            }

        }
        healthBar.SetHealth(currentHealth);
        scoreBar.SetScore(score);

        if(transform.localScale.x > 1){
            halfLife -= Time.deltaTime;
        }
        if(halfLife <= 0){
            halfLife = 5;
            // decreasing players size to half
            float newRadius = (transform.localScale.x/2)/(float)Math.Sqrt(2);
            transform.localScale = new Vector3(newRadius*2,newRadius*2,newRadius*2);


        }
        //half life alert
        if(halfLife > 0 && halfLife < 2){
            this.gameObject.GetComponent<SpriteRenderer>().sprite = shrinking;
        }
        else{
            this.gameObject.GetComponent<SpriteRenderer>().sprite = normal;
        }

        // if player is too small they die
        if(GetLocalSize() < 0.2f){
            Reset();
        }
    }

    


    public void Jump()
    {
        rb2d.AddForce(new Vector2(0, jmpForce));
    }
    public void Reset()
    {
        myAudioSource.PlayOneShot(hit);
        if(currentHealth == 1){
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);}
        else{
            currentHealth--;
            healthBar.SetHealth(currentHealth);
        }
    }

    public float GetLocalSize(){
        return transform.localScale.magnitude;
    }
    public float GetSize()
    {
        return transform.lossyScale.magnitude;
    }
    public void Eat(float sizeScale){
        myAudioSource.PlayOneShot(eat);
        score++;
        
        // Making the players size increase with a ratio to the enemy size

        float enemyArea = sizeScale*sizeScale*(float)Math.PI/4;
        float oldRadius = transform.localScale.x/2;
        float playerArea = oldRadius*oldRadius*(float)Math.PI;

        transform.localScale = transform.localScale + Vector3.one * sizeScale/2;
        float newRadius = (float)Math.Sqrt((enemyArea+playerArea)/(float)Math.PI);
        transform.localScale = new Vector3(newRadius*2,newRadius*2,newRadius*2);  
    }
}
