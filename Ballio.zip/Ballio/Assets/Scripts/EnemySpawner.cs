using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{

    public float spawnWidth = 1;
    public float spawnRate = 2;
    private float lastSpawnTime = 0;
    public GameObject enemy;    
    // Start is called before the first frame update
    void start(){
        enemy = GetComponent<GameObject>();
    }
    // Update is called once per frame
    void Update()
    {
        if (lastSpawnTime + 1 / spawnRate < Time.time) {
            lastSpawnTime = Time.time;
            Vector3 spawnPosition = transform.position;
            spawnPosition += new Vector3(Random.Range(-spawnWidth, spawnWidth), 5, 0);
			// the Instatiate function creates a new GameObject copy (clone) from a Prefab at a specific location and orientation.
            GameObject prefab = Instantiate(enemy, spawnPosition, Quaternion.identity);
        }
    }
    void OnDrawGizmos(){
		Gizmos.DrawLine (transform.position - new Vector3 (spawnWidth, 0, 0), transform.position + new Vector3 (spawnWidth, 0, 0));
		Gizmos.DrawLine (transform.position - new Vector3 (spawnWidth, 1, 0), transform.position - new Vector3 (spawnWidth, -1, 0));
		Gizmos.DrawLine (transform.position + new Vector3 (spawnWidth, 1, 0), transform.position + new Vector3 (spawnWidth, -1, 0));
	}
}
