using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{

    // Update is called once per frame
    private float sizeScale;

    void Awake(){
        sizeScale = Random.Range(0.2f,3.5f);
        transform.localScale = new Vector3(sizeScale,sizeScale,sizeScale);
    }

    float GetSize()
    {
        return transform.lossyScale.magnitude;
    }

    void OnCollisionEnter2D(Collision2D col){
        if(col.gameObject.CompareTag("Player")){
            // get player
            Player player = col.gameObject.GetComponent<Player>();
            float playerRad = player.GetSize();
            float enemyRad = GetSize();
            if(playerRad>=enemyRad){
                // player is bigger and eats enemy
                player.Eat(sizeScale);
                Destroy (gameObject);

            }
            else{
                // enemy is bigger and player takes damage
                print("player loses");
                player.Reset();
            }
        }
        else if(col.gameObject.CompareTag("platform")){
            Destroy (gameObject);
        }
    }
}
